    // Função para exibir a imagem de acordo com a área selecionada
    function atualizarImagem() {
      var area = document.getElementById('area').value;
      var imgResultado = document.getElementById('imgResultado');
      var imgSrc = '';

      switch (area) {
        case 'Esportes':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_esportes.png';
          break;
        case 'Assistentes':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_assistentes.png';
          break;
        case 'Uniforça':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_uniforca.png';
          break;
        case 'Atalaia':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_atalaia.png';
          break;
        case 'Cultura':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_cultura.png';
          break;
        case 'Midia':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_midia.png';
          break;
        case 'Help':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_help.png';
          break;
        case 'Universitarios':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_universitarios.png';
          break;
        case 'Arcanjos':
          imgSrc = 'https://forcajovemuniversal.com/wp-content/uploads/2021/02/patch_arcanjos.png';
          break;
        default:
          imgSrc = '';
      }

      if (imgSrc) {
        imgResultado.src = imgSrc;
        imgResultado.style.display = 'block';
      } else {
        imgResultado.style.display = 'none';
      }
    }

    // Função para mostrar o alerta personalizado
    //    function showAlert(nome, area) {
    //      var modal = document.getElementById("customAlert");
    //     var alertMessage = document.getElementById("alertMessage");

    //      alertMessage.innerHTML =
    //       '<strong style="color: Black; font-size: 25px;">Parabéns</strong> <strong style="color: blue; font-size: 28px;"><br>' + nome + '!</strong> <br>Você escolheu: <strong style="color: green;">' + area + '</strong>' +
    //      '<br><br>Sua resposta foi salva com sucesso!';

    //     modal.style.display = "block";
    //   }

    // Fechar o modal ao clicar no "X" do alerta
    //    document.querySelector('.close').addEventListener('click', function() {
    //      document.getElementById('customAlert').style.display = 'none';
    //      resetForm();
    //    });

    // Fechar o modal ao clicar fora do alerta
    window.addEventListener('click', function(event) {
      var modal = document.getElementById('customAlert');
      if (event.target == modal) {
        modal.style.display = 'none';
        resetForm();
      }
    });

    // Função para mostrar informações do projeto ao clicar na imagem
    function mostrarInfoProjeto() {
      var area = document.getElementById('area').value;
      var projectName = document.getElementById('projectName');
      var projectDescription = document.getElementById('projectDescription');
      var projectModal = document.getElementById('projectModal');

      var nomeProjeto = '';
      var descricaoProjeto = '';

      // Continuando a função para exibir informações do projeto
      switch (area) {
        case 'Esportes':
          nomeProjeto = 'Projeto Esportes';
          descricaoProjeto = 'O Projeto Esportes incentiva a prática de atividades físicas como ferramenta de inclusão, disciplina e trabalho em equipe.';
          break;
        case 'Assistentes':
          nomeProjeto = 'Projeto Assistentes';
          descricaoProjeto = 'Os Assistentes ajudam na organização de eventos, recepção de visitantes e atividades internas da FJU.';
          break;
        case 'Uniforça':
          nomeProjeto = 'Projeto Uniforça';
          descricaoProjeto = 'O Projeto Uniforça é responsável por auxiliar na segurança dos eventos e zelar pela ordem e disciplina nas atividades.';
          break;
        case 'Atalaia':
          nomeProjeto = 'Projeto Atalaia';
          descricaoProjeto = 'O Projeto Atalaia tem como missão ajudar os jovens a entenderem mais sobre evangelização e estarem preparados para a ação.';
          break;
        case 'Cultura':
          nomeProjeto = 'Projeto Cultura';
          descricaoProjeto = 'O Projeto Cultura visa promover talentos artísticos entre os jovens, incentivando a expressão por meio da música, teatro e dança.';
          break;
        case 'Midia':
          nomeProjeto = 'Projeto Mídia';
          descricaoProjeto = 'O Projeto Mídia é responsável por criar e divulgar conteúdos audiovisuais e gráficos que representem a FJU e seus eventos.';
          break;
        case 'Help':
          nomeProjeto = 'Projeto Help';
          descricaoProjeto = 'O Projeto Help oferece suporte psicológico e emocional para jovens, ajudando-os a enfrentar dificuldades emocionais.';
          break;
        case 'Universitarios':
          nomeProjeto = 'Projeto Universitários';
          descricaoProjeto = 'O Projeto Universitários apoia estudantes universitários na busca por uma vida acadêmica equilibrada e com propósito.';
          break;
        case 'Arcanjos':
          nomeProjeto = 'Projeto Arcanjos';
          descricaoProjeto = ' projecto arcanjo na FJU tem a missão de resgatar a todos os jovens que se encontram afastados da presença de Deus e os voluntários do mesmo não medem esforços nem têm limites para o fazer.';
          break;
      }

      projectName.innerText = nomeProjeto;
      projectDescription.innerText = descricaoProjeto;
      projectModal.style.display = 'block';
    }

    // Fechar o modal do projeto ao clicar no "X"
    document.getElementById('closeProjectModal').addEventListener('click', function() {
      document.getElementById('projectModal').style.display = 'none';
    });

    // Fechar o modal do projeto ao clicar fora do conteúdo
    window.addEventListener('click', function(event) {
      var modal = document.getElementById('projectModal');
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    });

    // Função para resetar o formulário
    function resetForm() {
      document.getElementById('enqueteForm').reset();
      document.getElementById('imgResultado').style.display = 'none';
    }

    // Manipulador de envio do formulário
    document.getElementById('enqueteForm').addEventListener('submit', function(e) {
      e.preventDefault();

      var nome = document.getElementById('nome').value;
      var area = document.getElementById('area').value;

      // Mostrar o alerta personalizado
      showAlert(nome, area);
    });

    // Mostrar informações do projeto ao clicar na imagem
    document.getElementById('imgResultado').addEventListener('click', function() {
      mostrarInfoProjeto();
    });

    // Atualizar a imagem ao mudar o projeto selecionado
    document.getElementById('area').addEventListener('change', atualizarImagem);


    // Função para definir um cookie
    function setCookie(cname, cvalue, exdays) {
      const d = new Date();
      d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
      const expires = "expires=" + d.toUTCString();
      document.cookie = `${cname}=${cvalue};${expires};path=/;Secure;SameSite=Strict`;
    }

    // Função para obter um cookie
    function getCookie(cname) {
      const name = cname + "=";
      const decodedCookie = decodeURIComponent(document.cookie);
      const ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i].trim();
        if (c.indexOf(name) === 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }

    // Função para verificar se o formulário já foi enviado
    function checkSubmission() {
      const submitted = getCookie("submitted");
      return submitted !== "true"; // Se já foi enviado, retorna false
    }

    // Função para mostrar o modal com mensagem
    function showModal(message) {
      document.getElementById('modalMessage').innerText = message;
      document.getElementById('myModal').style.display = 'block';
    }

    // Função para fechar o modal
    function closeModal() {
      document.getElementById('myModal').style.display = 'none';
    }

    // Evento de envio do formulário
    document.getElementById('enqueteForm').addEventListener('submit', function(e) {
      e.preventDefault();

      // Verifica se o formulário já foi enviado
      if (!checkSubmission()) {
        // Se já foi enviado, mostra a mensagem de aviso
        showModal("Você já enviou este formulário.");
        return; // Não prossegue
      }

      var nome = document.getElementById('nome').value;
      var area = document.getElementById('area').value;

      // Obter a data e hora atuais no horário de Brasília
      var agora = new Date();
      var options = {
        timeZone: 'America/Sao_Paulo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false // Para usar o formato 24 horas
      };

      var dataHora = new Intl.DateTimeFormat('pt-BR', options).format(agora);

      // Para formatar a data no formato DD/MM/YYYY HH:mm:ss
      var [dia, mes, ano, hora, minuto, segundo] = dataHora.split(/[\s:\/]+/);
      var dataFormatada = `${dia}/${mes}/${ano} ${hora}:${minuto}:${segundo}`;

      // Definir o cookie ANTES de enviar os dados para a API
      setCookie("submitted", "true", 21); // 365 diasDefine o cookie ao enviar

      // Enviar dados para a planilha via API
      fetch('https://api.sheetmonkey.io/form/c9pELK77cNbcVH4PdB4DDH', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            Nome: nome,
            'Nome do Projeto': area,
            'Data e Hora': dataFormatada // Campo adicional para a data e hora
          }),
        })
        .then(response => {
          if (!response.ok) {
            throw new Error('Erro ao enviar os dados');
          }
          return response.json();
        })
        .then(data => {
          // Mostrar o alerta personalizado após enviar os dados com sucesso
          showAlert(nome, area);
        })
        .catch(error => {
          console.error('Erro ao enviar os dados:', error);
        });
    });

    // Função para mostrar o alerta de sucesso
    function showAlert(nome, area) {
      showModal(`Parabéns!\nVocê escolheu: ${area}\nSua resposta foi salva com sucesso!`);
    }
